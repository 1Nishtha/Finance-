const API_URL = "http://localhost:8080/api/transactions";

// Add new transaction
document.getElementById("transactionForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const description = document.getElementById("description").value;
  const amount = parseFloat(document.getElementById("amount").value);
  const type = document.getElementById("type").value;
  const date = document.getElementById("date").value;

  const transaction = { description, amount, type, date };

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(transaction)
  });

  e.target.reset();
  loadTransactions();
});

// Load all transactions and update dashboard
async function loadTransactions() {
  const res = await fetch(API_URL);
  const data = await res.json();

  updateDashboard(data);

  const tableBody = document.querySelector("#transactionTable tbody");
  tableBody.innerHTML = "";

  data.forEach(tx => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${tx.description}</td>
      <td>₹${tx.amount.toFixed(2)}</td>
      <td>${tx.type}</td>
      <td>${tx.date}</td>
      <td><button class="delete-btn" onclick="deleteTransaction(${tx.id})">Delete</button></td>
    `;

    tableBody.appendChild(row);
  });
}

// Update dashboard summary totals
function updateDashboard(transactions) {
  let income = 0, expense = 0;

  transactions.forEach(tx => {
    if (tx.type === "income") income += tx.amount;
    else if (tx.type === "expense") expense += tx.amount;
  });

  const balance = income - expense;

  document.getElementById("totalIncome").textContent = `₹${income.toFixed(2)}`;
  document.getElementById("totalExpense").textContent = `₹${expense.toFixed(2)}`;
  document.getElementById("balance").textContent = `₹${balance.toFixed(2)}`;
}

// Delete transaction
async function deleteTransaction(id) {
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  loadTransactions();
}

// Initial load
loadTransactions();
